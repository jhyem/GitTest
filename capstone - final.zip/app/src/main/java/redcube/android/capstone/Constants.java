package redcube.android.capstone;

public class Constants {
    // 서버 기본 URL
    //public static final String BASE_URL = "http://10.0.2.2:8080";
    //public static final String GPT_BASE_URL = "http://10.0.2.2:8081";


    public static final String BASE_URL = "http://221.150.87.66:8080";
    public static final String GPT_BASE_URL = "http://221.150.87.66:8081";

    // API 엔드포인트
    public static final String PRICE_API = "/api/price";
    public static final String GPT_API = "/api/chat";
} 