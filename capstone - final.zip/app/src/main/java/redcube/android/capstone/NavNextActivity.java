package redcube.android.capstone;

import android.content.Context;
import android.content.Intent;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class NavNextActivity {
    public static void setupBottomNavigation(Context context, BottomNavigationView bottomNav) {
        // 현재 Context가 어떤 액티비티인지 확인
        if (context instanceof SelectItemActivity) {
            bottomNav.setSelectedItemId(R.id.nav_home);
        } else if (context instanceof GoogleMapActivity) {
            bottomNav.setSelectedItemId(R.id.nav_sticker);
        } else if (context instanceof ChatMain) {
            bottomNav.setSelectedItemId(R.id.nav_chatbot);
        }


        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.nav_sticker) {
                if (!(context instanceof GoogleMapActivity)) {
                    context.startActivity(new Intent(context, GoogleMapActivity.class));
                }
                return true;
            } else if (itemId == R.id.nav_home) {
                if (!(context instanceof SelectItemActivity)) {
                    context.startActivity(new Intent(context, SelectItemActivity.class));
                }
                return true;
            } else if (itemId == R.id.nav_chatbot) {
                if (!(context instanceof ChatMain)) {
                    context.startActivity(new Intent(context, ChatMain.class));
                }
                return true;
            }

            return false;
        });
    }
}
