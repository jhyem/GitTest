package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class ChatController {

    @Value("${openai.api.key}")
    private String apiKey;

    private final WebClient webClient;

    public ChatController() {
        this.webClient = WebClient.builder()
                .baseUrl("https://api.openai.com/v1")
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    @CrossOrigin(origins = "*")
    @PostMapping("/chat")
    public Mono<Map<String, String>> chat(@RequestParam String message) {
    	System.out.println("✅ WebClient 방식 실행됨");
    	
        ChatGPTRequest request = new ChatGPTRequest(
                "gpt-3.5-turbo",
                List.of(new ChatGPTRequest.Message("user", message))
        );

        return webClient.post()
                .uri("/chat/completions")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(ChatGPTResponse.class)
                .map(response -> {
                    String reply = response.getChoices().get(0).getMessage().getContent();
                    Map<String, String> result = new HashMap<>();
                    result.put("reply", reply);
                    return result;
                })
                .onErrorResume(e -> {
                    Map<String, String> error = new HashMap<>();
                    error.put("reply", "GPT 응답 중 오류 발생: " + e.getMessage());
                    return Mono.just(error);
                });
    }
}
