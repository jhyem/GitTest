package redcube.android.capstone;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONException;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Locale;

public class CameraResultActivity extends AppCompatActivity {
    private ImageView capturedImageView;
    private TextView furnitureInfoTextView;
    private ImageButton confirmButton;
    private int priceFromServer = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_camera_result);

        capturedImageView = findViewById(R.id.capturedImageView);
        furnitureInfoTextView = findViewById(R.id.furnitureInfoTextView);
        confirmButton = findViewById(R.id.confirmButton);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        NavNextActivity.setupBottomNavigation(this, bottomNavigationView);

        //String category = getIntent().getStringExtra("selectedCategory");
        //float measuredDistance = getIntent().getFloatExtra("distance1", 0f);
        //float measuredDistance2 = getIntent().getFloatExtra("distance2", 0f);
        //String imagePath = getIntent().getStringExtra("imagePath");

        String category = "공기청정기";
        float measuredDistance = 100;
        float measuredDistance2 = 0;
        String imagePath = "";

        // 거리 텍스트 표시
        String distanceText = String.format(Locale.getDefault(),
                "가구: %s\n폐기물 규격 : %.1f cm x %.1f cm",
                category,
                measuredDistance,
                measuredDistance2);
        furnitureInfoTextView.setText(distanceText);

        // 서버에서 가격 가져오기
        RequestQueue queue = Volley.newRequestQueue(this);
        String encodedItem;
        try {
            encodedItem = URLEncoder.encode(category, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            Toast.makeText(this, "품목 인코딩 실패", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = null;
        try {
            url = "http://localhost:8080/api/price?item=" + URLEncoder.encode(category, "UTF-8")
                    + "&width=" + measuredDistance + "&height=" + measuredDistance2;
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        priceFromServer = response.getInt("fee");
                        Log.d("CameraResult", "받은 가격: " + priceFromServer);
                    } catch (JSONException e) {
                        Toast.makeText(this, "서버 응답 파싱 실패", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "서버 연결 실패", Toast.LENGTH_SHORT).show()
        );
        queue.add(request);

        // 확인 버튼 눌렀을 때
        confirmButton.setOnClickListener(v -> {
            Dialog dialog = new Dialog(CameraResultActivity.this);
            dialog.setContentView(R.layout.custom_dialog_same_size);

            Button btnYes = dialog.findViewById(R.id.btnYes);
            Button btnNo = dialog.findViewById(R.id.btnNo);

            btnYes.setOnClickListener(view -> {
                dialog.dismiss();
                Intent intent = new Intent(CameraResultActivity.this, StickerPriceActivity.class);
                intent.putExtra("imagePath", imagePath);
                intent.putExtra("result", category);
                intent.putExtra("price", priceFromServer);
                startActivity(intent);
            });

            btnNo.setOnClickListener(view -> {
                dialog.dismiss();
                showManualInputDialog(category, imagePath);
            });

            dialog.show();
        });
    }
    private void showManualInputDialog(String category, String imagePath) {
        boolean isAreaBased = category.equals("거울") ||
                category.equals("어항") ||
                category.equals("조명기구") ||
                category.equals("유리");

        Dialog dialog = new Dialog(CameraResultActivity.this);
        dialog.setContentView(isAreaBased ? R.layout.custom_dialog_input_size2 : R.layout.custom_dialog_input_size);

        if (isAreaBased) {
            EditText inputWidthEditText = dialog.findViewById(R.id.inputWidthEditText);
            EditText inputHeightEditText = dialog.findViewById(R.id.inputHeightEditText);
            Button btnOk = dialog.findViewById(R.id.btnOk);
            Button btnCancel = dialog.findViewById(R.id.btnCancel);

            btnOk.setOnClickListener(view -> {
                try {
                    float width = Float.parseFloat(inputWidthEditText.getText().toString());
                    float height = Float.parseFloat(inputHeightEditText.getText().toString());

                    // 서버에 요청 보내기
                    String encodedItem = URLEncoder.encode(category, "UTF-8");
                    String url = "http://localhost:8080/api/price?item=" + encodedItem
                            + "&width=" + width + "&height=" + height;

                    JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                            response -> {
                                try {
                                    int serverPrice = response.getInt("fee");

                                    Intent intent = new Intent(CameraResultActivity.this, StickerPriceActivity.class);
                                    intent.putExtra("imagePath", imagePath);
                                    intent.putExtra("result", category);
                                    intent.putExtra("price", serverPrice);
                                    startActivity(intent);

                                } catch (JSONException e) {
                                    Toast.makeText(this, "서버 응답 파싱 실패", Toast.LENGTH_SHORT).show();
                                }
                            },
                            error -> Toast.makeText(this, "서버 요청 실패", Toast.LENGTH_SHORT).show()
                    );

                    Volley.newRequestQueue(CameraResultActivity.this).add(request);
                    dialog.dismiss();

                } catch (Exception e) {
                    Toast.makeText(CameraResultActivity.this, "숫자를 정확히 입력해주세요", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            EditText inputSizeEditText = dialog.findViewById(R.id.inputSizeEditText);
            Button btnOk = dialog.findViewById(R.id.btnOk);
            Button btnCancel = dialog.findViewById(R.id.btnCancel);

            inputSizeEditText.setHint("가로 (cm)");

            btnOk.setOnClickListener(view -> {
                try {
                    float width = Float.parseFloat(inputSizeEditText.getText().toString());

                    // 서버에 요청 보내기
                    String encodedItem = URLEncoder.encode(category, "UTF-8");
                    String url = "http://localhost:8080/api/price?item=" + encodedItem
                            + "&width=" + width + "&height=0";

                    JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                            response -> {
                                try {
                                    int serverPrice = response.getInt("fee");

                                    Intent intent = new Intent(CameraResultActivity.this, StickerPriceActivity.class);
                                    intent.putExtra("imagePath", imagePath);
                                    intent.putExtra("result", category);
                                    intent.putExtra("price", serverPrice);
                                    startActivity(intent);

                                } catch (JSONException e) {
                                    Toast.makeText(this, "서버 응답 파싱 실패", Toast.LENGTH_SHORT).show();
                                }
                            },
                            error -> Toast.makeText(this, "서버 요청 실패", Toast.LENGTH_SHORT).show()
                    );

                    Volley.newRequestQueue(CameraResultActivity.this).add(request);
                    dialog.dismiss();

                } catch (Exception e) {
                    Toast.makeText(CameraResultActivity.this, "숫자를 정확히 입력해주세요", Toast.LENGTH_SHORT).show();
                }
            });
        }

        Button btnCancel = dialog.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(view -> dialog.dismiss());
        dialog.show();
    }

}