package com.example.pyegibot.repository;

import com.example.pyegibot.entity.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface HomeApplianceRepository extends JpaRepository<HomeAppliance, Integer> {
    @Query("SELECT h FROM HomeAppliance h WHERE h.item = :item")
    Optional<HomeAppliance> findByItem(@Param("item") String item);
}