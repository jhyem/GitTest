package com.example.pyegibot.entity;

import jakarta.persistence.*;
import lombok.Getter;

@Getter
@Entity
@Table(name = "home_appliances")
public class HomeAppliance {

    @Id
    private int id;

    private int category;

    private String item;

    private String standard;  // ✅ "높이 1m 이상" 같은 조건이 들어감

    private int fee;
}
