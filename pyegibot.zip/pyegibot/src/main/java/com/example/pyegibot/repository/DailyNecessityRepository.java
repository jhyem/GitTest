package com.example.pyegibot.repository;

import com.example.pyegibot.entity.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface DailyNecessityRepository extends JpaRepository<DailyNecessity, Integer> {
    @Query("SELECT d FROM DailyNecessity d WHERE d.item LIKE CONCAT(:baseItem, '%')")
    List<DailyNecessity> findVariantsOfItem(@Param("baseItem") String baseItem);
}