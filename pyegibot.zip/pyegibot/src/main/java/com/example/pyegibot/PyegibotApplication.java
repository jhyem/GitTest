package com.example.pyegibot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PyegibotApplication {
	public static void main(String[] args) {
		SpringApplication.run(PyegibotApplication.class, args);
	}
}