package com.example.pyegibot.repository;

import com.example.pyegibot.entity.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface FurnitureRepository extends JpaRepository<Furniture, Integer> {
    @Query("SELECT f FROM Furniture f WHERE f.item LIKE CONCAT(:baseItem, '%')")
    List<Furniture> findVariantsOfItem(@Param("baseItem") String baseItem);
}
