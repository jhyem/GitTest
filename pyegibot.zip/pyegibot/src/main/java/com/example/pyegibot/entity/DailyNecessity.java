package com.example.pyegibot.entity;

import jakarta.persistence.*;
import lombok.Getter;

@Entity
@Getter
@Table(name = "daily_necessities")
public class DailyNecessity {
    @Id
    private int id;
    private int category;
    private String item;
    private String standard1;
    private String standard2;
    private int fee;
}