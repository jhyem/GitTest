package com.example.pyegibot.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;

@Entity
@Getter
@Table(name = "furniture")
public class Furniture {
    @Id
    private int id;
    private int category;
    private String item;
    private String standard1;
    private String standard2;
    private int fee;
}
