package com.example.pyegibot.controller;

import com.example.pyegibot.service.PriceService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class PriceController {
    private final PriceService priceService;

    public PriceController(PriceService priceService) {
        this.priceService = priceService;
    }

    @GetMapping("/price")
    public ResponseEntity<?> getPrice(@RequestParam String item,
                                      @RequestParam(required = false) Float width,
                                      @RequestParam(required = false) Float height) {
        return priceService.findFeeByItemAndSize(item, width, height)
                .map(fee -> ResponseEntity.ok(Map.of("item", item, "fee", fee)))
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "not found")));
    }
}
