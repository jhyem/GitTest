package com.example.pyegibot.service;

import com.example.pyegibot.entity.DailyNecessity;
import com.example.pyegibot.entity.Furniture;
import com.example.pyegibot.entity.HomeAppliance;
import com.example.pyegibot.repository.DailyNecessityRepository;
import com.example.pyegibot.repository.FurnitureRepository;
import com.example.pyegibot.repository.HomeApplianceRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PriceService {
    private final HomeApplianceRepository homeRepo;
    private final FurnitureRepository furnitureRepo;
    private final DailyNecessityRepository dailyRepo;

    public PriceService(HomeApplianceRepository homeRepo, FurnitureRepository furnitureRepo, DailyNecessityRepository dailyRepo) {
        this.homeRepo = homeRepo;
        this.furnitureRepo = furnitureRepo;
        this.dailyRepo = dailyRepo;
    }

    public Optional<Integer> findFeeByItemAndSize(String item, Float width, Float height) {
        // 1. 홈어플라이언스
        Optional<HomeAppliance> appliance = homeRepo.findByItem(item);
        if (appliance.isPresent()) {
            HomeAppliance a = appliance.get();
            if (matchesSize(a.getStandard(), width)) {
                return Optional.of(a.getFee());
            } else {
                return Optional.of(0);
            }
        }

        // 2. 가구류: 책장 → 책장(1), 책장(2)... 으로 LIKE 검색
        List<Furniture> furnitures = furnitureRepo.findVariantsOfItem(item);
        for (Furniture f : furnitures) {
            if (matchesSize(f.getStandard1(), width) && matchesSize(f.getStandard2(), height)) {
                return Optional.of(f.getFee());
            }
        }

        // 3. 생활용품류
        List<DailyNecessity> dailies = dailyRepo.findVariantsOfItem(item);
        for (DailyNecessity d : dailies) {
            if (matchesSize(d.getStandard1(), width) && matchesSize(d.getStandard2(), height)) {
                return Optional.of(d.getFee());
            }
        }

        return Optional.empty();
    }

    private boolean matchesSize(String standard, Float actual) {
        if (standard == null || standard.isBlank()) return true;
        if (actual == null) return false;

        String s = standard.replaceAll("[^0-9.]", "");
        float value;
        try {
            value = Float.parseFloat(s);
        } catch (NumberFormatException e) {
            return false;
        }

        if (standard.contains("이상")) return actual >= value;
        if (standard.contains("초과")) return actual > value;
        if (standard.contains("미만")) return actual < value;
        if (standard.contains("이하")) return actual <= value;
        return actual == value;
    }
}
