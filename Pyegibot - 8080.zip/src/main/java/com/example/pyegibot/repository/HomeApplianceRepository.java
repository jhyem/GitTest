package com.example.pyegibot.repository;

import com.example.pyegibot.entity.HomeAppliance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface HomeApplianceRepository extends JpaRepository<HomeAppliance, Integer> {
    @Query("SELECT h FROM HomeAppliance h WHERE h.item = :item")
    Optional<HomeAppliance> findByItem(@Param("item") String item);
}