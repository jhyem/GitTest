package com.example.pyegibot.repository;

import com.example.pyegibot.entity.Furniture;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FurnitureRepository extends JpaRepository<Furniture, Integer> {
    @Query("SELECT f FROM Furniture f WHERE f.item LIKE CONCAT(:baseItem, '%')")
    List<Furniture> findVariantsOfItem(@Param("baseItem") String baseItem);
}
