package min.mjc.chatbottest;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ChatGPTApi {

    @Headers({
            "Authorization: Bearer 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",  // 여기에 실제 API 키를 넣으세요
            "Content-Type: application/json"
    })
    @POST("v1/chat/completions")
    Call<ChatGPTResponse> sendMessage(@Body ChatGPTRequest request);
}
