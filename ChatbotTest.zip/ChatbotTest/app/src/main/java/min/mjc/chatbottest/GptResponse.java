package min.mjc.chatbottest;

public class GptResponse {

    private String reply;

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }
}